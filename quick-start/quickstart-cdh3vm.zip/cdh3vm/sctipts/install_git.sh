# gitのインストール
apt-get install -y git

