sudo ./scripts/install_mysql.sh
sudo ./scripts/install_git.sh
sudo ./scripts/install_maven.sh
sudo configure_apparmor.sh
./scripts/configure_ssh.sh
./scripts/congifure_bashrc.sh
